<?php

namespace App\Order\Models;

use Illuminate\Database\Eloquent\Model;

class Migrations extends Model {
    
}
