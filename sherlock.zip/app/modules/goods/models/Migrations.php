<?php

namespace App\Goods\Models;

use Illuminate\Database\Eloquent\Model;

class Migrations extends Model {
    
}
