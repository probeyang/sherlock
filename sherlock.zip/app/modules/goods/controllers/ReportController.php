<?php

namespace App\Modules\Goods\Controllers;

class ReportController extends \Probeyang\Sherlock\Core\Web\WebController {

    public function start() {
        $blog = \App\Models\Pages::first();
//        $this->render(new Pages());
//        $this->render(['blog' => $blog]);
        $this->render('list',['blog' => $blog]);
    }

}
