<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo $blog['title'] ?></title>
    </head>

    <body>
        <div class="article">
            <h1><?php echo $blog['title'] ?></h1>
            <div class="content">
                <?php echo $blog['body'] ?>
            </div>
        </div>

        <ul class="cp">
            <li>this is report list.content part</li>
            <li>
                <?php echo $blog['created_at']; ?>
            </li>
        </ul>
    </body>
</html>

