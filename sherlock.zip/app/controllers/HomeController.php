<?php

namespace App\Controllers;

use Probeyang\Sherlock\Core\Web\WebController;
use \App\Models\Article;
use \App\Models\Pages;

class HomeController extends WebController {

    public function home() {
//        $article = new Article();
        var_dump(\App\Order\Models\Migrations::first());
        var_dump(Article::first());
        var_dump("here success");
    }

    public function view() {
//        $pages = new Pages();
        $blog = Pages::first();
//        $this->render(new Pages());
        $this->render(['blog' => $blog]);
//        $this->render('home/detail',['blog' => $blog]);
//        $this->render(['blog' => $blog]);
//        $this->render('view',['blog' => $blog]);
//        $this->render('home/view',['blog' => $blog]);
    }

    public function index() {
//        $article = new Article();
        return view('index')->with('article', Article::first())
                        ->withTitle('我的title信息')
                        ->withContent("我的content信息");
//        $this->view = View('index')->with('article', Article::first())
//                ->withTitle('this is a title,yes')
//                ->withContent('this is content');
    }

}
