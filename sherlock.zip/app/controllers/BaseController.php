<?php

namespace App\Controllers;

use Probeyang\Sherlock\Core\Web\WebController;

class BaseController extends WebController {

    public $view;

    public function __construct() {
        
    }

    public function __destruct() {
        $view = $this->view;
        if ($view instanceof View) {
            extract($view->data);
            require $view->view;
        }
    }

}
