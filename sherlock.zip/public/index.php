<?php

//定义BASE_DIR
define('BASE_DIR', dirname(__DIR__));
// Autoload 自动载入
require BASE_DIR . '/vendor/autoload.php';
//系统运行
Holmes::app()->run();

