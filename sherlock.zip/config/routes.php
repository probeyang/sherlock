<?php

use Probeyang\Sherlock\Router\Router;

Router::get('hello', function() {
    echo "成功！";
});

//Router::get('(:all)', function($args) {
//    echo '未匹配到路由<br>' . $args;
//});

Router::get('', 'HomeController@index');
Router::get('view', 'HomeController@view');
Router::get('home', 'HomeController@home');
Router::get('index', 'HomeController@index');
Router::get('goods/report/start', 'Goods/ReportController@start');

Router::$error_callback = function() {
    throw new Exception("路由无匹配项 404 Not Found");
};

