<?php

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'modules' => [
        'order' => [
            'namespace' => 'app\modules\order',
        ],
        'goods' => [
            'namespace' => 'app\modules\goods',
        ],
    ],
];
return $config;
